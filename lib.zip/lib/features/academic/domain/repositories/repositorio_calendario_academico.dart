import '../entities/dia_academico.dart';

abstract class RepositorioCalendarioAcademico {
  Future<List<DiaAcademico>> obtenerPorPlanId(String planId);
}
