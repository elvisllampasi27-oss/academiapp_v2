import '../entities/contexto_dia_estudiante.dart';
import '../entities/dia_academico.dart';
import '../repositories/repositorio_curso.dart';
import '../repositories/repositorio_plan_academico.dart';
import '../repositories/repositorio_tema.dart';
import 'actividades_del_dia_service.dart';
import 'calendario_academico_service.dart';
import 'secuencia_academica_service.dart';

class ConstruirDiaEstudianteService {
  final RepositorioPlanAcademico repositorioPlan;
  final RepositorioCurso repositorioCurso;
  final RepositorioTema repositorioTema;

  const ConstruirDiaEstudianteService({
    required this.repositorioPlan,
    required this.repositorioCurso,
    required this.repositorioTema,
  });

  Future<ContextoDiaEstudiante?> construir({
    required String versionId,
    required DateTime fechaInicioAcademico,
    required DateTime fechaActual,
  }) async {
    final plan = await repositorioPlan.buscarActivoPorVersionId(versionId);

    if (plan == null) {
      return null;
    }

    final cursos = await repositorioCurso.obtenerActivos();
    final temas = await repositorioTema.obtenerActivos();

    final secuencia = const SecuenciaAcademicaService().generar(
      cursos: cursos,
      temas: temas,
    );

    final calendario = const CalendarioAcademicoService().generar(
      secuencia: secuencia,
      fechaInicio: fechaInicioAcademico,
    );

    final actividades = const ActividadesDelDiaService().obtener(
      calendario: calendario,
      fecha: fechaActual,
    );

    DiaAcademico? diaActual;

    for (final dia in calendario) {
      if (dia.fecha == null) {
        continue;
      }

      final fechaDia = DateTime(
        dia.fecha!.year,
        dia.fecha!.month,
        dia.fecha!.day,
      );

      final hoy = DateTime(
        fechaActual.year,
        fechaActual.month,
        fechaActual.day,
      );

      if (fechaDia == hoy) {
        diaActual = dia;
        break;
      }
    }

    return ContextoDiaEstudiante(
      plan: plan,
      dia: diaActual,
      actividades: actividades,
      cursos: cursos,
      temas: temas,
    );
  }
}
