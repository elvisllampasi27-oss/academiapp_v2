import 'package:cloud_firestore/cloud_firestore.dart';

import '../../domain/entities/actividad_programada.dart';
import '../../domain/entities/dia_academico.dart';
import '../../domain/repositories/repositorio_calendario_academico.dart';

class RepositorioCalendarioAcademicoFirestore
    implements RepositorioCalendarioAcademico {
  final FirebaseFirestore firestore;

  RepositorioCalendarioAcademicoFirestore({FirebaseFirestore? firestore})
    : firestore = firestore ?? FirebaseFirestore.instance;

  @override
  Future<List<DiaAcademico>> obtenerPorPlanId(String planId) async {
    final consulta = await firestore
        .collection('dias_academicos')
        .where('planId', isEqualTo: planId)
        .orderBy('numero')
        .get();

    return consulta.docs.map((documento) {
      final datos = documento.data();

      final actividadesDatos =
          (datos['actividades'] as List<dynamic>? ?? const []);

      final actividades = actividadesDatos.map((item) {
        final actividad = item as Map<String, dynamic>;

        return ActividadProgramada(
          id: actividad['id'] as String,
          diaId: documento.id,
          temaId: actividad['temaId'] as String,
          orden: actividad['orden'] as int,
          tipo: _convertirTipo(actividad['tipo'] as String),
          estado: _convertirEstado(actividad['estado'] as String),
        );
      }).toList();

      return DiaAcademico(
        numero: datos['numero'] as int,
        planId: datos['planId'] as String,
        fecha: (datos['fecha'] as Timestamp).toDate(),
        actividades: actividades,
      );
    }).toList();
  }

  TipoActividadProgramada _convertirTipo(String tipo) {
    return switch (tipo) {
      'tema' => TipoActividadProgramada.tema,
      'reforzamiento' => TipoActividadProgramada.reforzamiento,
      _ => throw StateError('Tipo de actividad desconocido: $tipo'),
    };
  }

  EstadoActividadProgramada _convertirEstado(String estado) {
    return switch (estado) {
      'preparada' => EstadoActividadProgramada.preparada,
      'publicada' => EstadoActividadProgramada.publicada,
      'archivada' => EstadoActividadProgramada.archivada,
      _ => throw StateError('Estado de actividad desconocido: $estado'),
    };
  }
}
